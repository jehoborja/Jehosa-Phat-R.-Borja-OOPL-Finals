/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class Bid {
    private String bidderName;
    private double amount;

    public Bid(String bidderName, double amount) {
        this.bidderName = bidderName;
        this.amount = amount;
    }

    public String getBidderName() {
        return bidderName;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return String.format("%s: $%.2f", bidderName, amount);
    }
}

class Item {
    private String itemName;

    public Item(String itemName) {
        this.itemName = itemName;
    }

    public String getItemName() {
        return itemName;
    }

    @Override
    public String toString() {
        return itemName;
    }
}

class Auction {
    private Item item;
    private double currentBid;
    private String currentBidder;
    private List<Bid> bidHistory;

    public Auction(Item item) {
        this.item = item;
        currentBid = 0.0;
        currentBidder = null;
        bidHistory = new ArrayList<>();
    }

    public Item getItem() {
        return item;
    }

    public double getCurrentBid() {
        return currentBid;
    }

    public String getCurrentBidder() {
        return currentBidder;
    }

    public List<Bid> getBidHistory() {
        return new ArrayList<>(bidHistory);
    }

    public void placeBid(String bidderName, double amount) {
        if (amount > currentBid) {
            currentBid = amount;
            currentBidder = bidderName;
            bidHistory.add(new Bid(bidderName, amount));
            System.out.println("Bid placed successfully.");
        } else {
            System.out.println("Bid amount must be higher than the current bid.");
        }
    }
}

class AuctionSystem {
    private List<Auction> auctions;

    public AuctionSystem() {
        auctions = new ArrayList<>();
    }

    public void createAuction(Item item) {
        auctions.add(new Auction(item));
        System.out.println("Auction created successfully for item: " + item.getItemName());
    }

    public List<Auction> getAuctions() {
        return new ArrayList<>(auctions);
    }
}

public class Main{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AuctionSystem auctionSystem = new AuctionSystem();

        while (true) {
            System.out.println("\n1. Create Auction");
            System.out.println("2. View Auctions");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter item name for the auction: ");
                    String itemName = scanner.nextLine();
                    auctionSystem.createAuction(new Item(itemName));
                    break;
                case 2:
                    List<Auction> auctions = auctionSystem.getAuctions();
                    if (auctions.isEmpty()) {
                        System.out.println("No auctions available.");
                    } else {
                        System.out.println("\nAvailable Auctions:");
                        for (int i = 0; i < auctions.size(); i++) {
                            System.out.println((i + 1) + ". Auction for Item: " + auctions.get(i).getItem());
                        }

                        System.out.print("Enter auction number to participate: ");
                        int auctionNumber = scanner.nextInt();
                        scanner.nextLine();

                        if (auctionNumber >= 1 && auctionNumber <= auctions.size()) {
                            participateInAuction(auctions.get(auctionNumber - 1), scanner);
                        } else {
                            System.out.println("Invalid auction number.");
                        }
                    }
                    break;
                case 3:
                    System.out.println("Exiting the program.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void participateInAuction(Auction auction, Scanner scanner) {
        System.out.println("\nWelcome to Auction for Item: " + auction.getItem());
        while (true) {
            System.out.println("\nCurrent Bid: $" + auction.getCurrentBid());
            System.out.println("Current Bidder: " + (auction.getCurrentBidder() != null ? auction.getCurrentBidder() : "None"));
            System.out.println("Bid History: " + auction.getBidHistory());

            System.out.print("\nEnter your name (or 'exit' to leave the auction): ");
            String bidderName = scanner.nextLine();

            if (bidderName.equalsIgnoreCase("exit")) {
                System.out.println("Leaving the auction. Final bid: $" + auction.getCurrentBid() + " by " + auction.getCurrentBidder());
                break;
            }

            System.out.print("Enter your bid amount: $");
            double amount = scanner.nextDouble();
            scanner.nextLine();

            auction.placeBid(bidderName, amount);
        }
    }
}

